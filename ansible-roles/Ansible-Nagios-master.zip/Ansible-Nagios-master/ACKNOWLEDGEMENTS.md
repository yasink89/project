This ansible role was based on the following cookbooks and roles:

https://github.com/networklore/ansible-role-nagios - Patrick Ogenstad    
https://github.com/networklore/ansible-role-nrpe-client    
https://github.com/npm/ansible-nagios-config - Benjamin E. Coe   
https://github.com/schubergphilis/nrpe    
https://github.com/schubergphilis/nagios    
https://github.com/chef-cookbooks/users   
https://github.com/mivok/ansible-users   
